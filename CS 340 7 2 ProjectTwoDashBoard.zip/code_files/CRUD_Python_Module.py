# Example Python Code to Insert a Document 
# Database: CRUD
# Collection: animals
# User: aacuser

from dash import Dash, html, dcc
from dash import dash_table
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
#from typing import Any, Dict, List, Optional
from pymongo import MongoClient 
from pymongo.errors import PyMongoError
from urllib.parse import quote_plus 
# from CRUD_Python_Module import AnimalShelterCRUD

class AnimalShelterCRUD:
    
   # CRUD operations for Animal collection in MongoDB  
    def __init__(self, db_name="AAC", collection_name="animal", username=None, password=None):
        self.db_name = db_name
        self.collection_name = collection_name
        
        if username and password:
            uri = f"mongodb://{username}:{quote_plus(password)}@localhost:27017/?authSource=admin"
        else:
            uri = "mongodb://localhost:27017/"
        
      #  uri = f"mongodb://{name}:{quote_plus(password)}@localhost:27017/?authSource=admin"
        try:
            
            self.client = MongoClient(uri)
        
            self.client .admin.command("ping")
            self.database = self.client[self.db_name]
            self.collection = self.database[self.collection_name]
            
        except PyMongoError as e:
            
            raise ConnectionError(f"MongoDB connection failed: {e}")
        
  
    # CREATE
                
    def create(self, data):
        # Insert one document. Returns True if inserted, else False. 
        
        if data is None:
          # insert_result = self.database.animals.insert_one(data) 
          #  else:                             
          return False
        try:
            result = self.collection.insert_one(data) 
            return result.acknowledged 
        except PyMongoError: 
            return False
        
            
    # READ
    def read(self, query):
                                     
      # Find documents. Returns list of results, else empty list.
        if query is None:
           
           return []
       
        try:
           return list(self.collection.find(query))
        except PyMongoError:
            return[]   

    # UPDATE 
  
    # def update(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> int:
    def update(self, query, new_data):
        # Update documents matching query. Returns number of modified docs.     
        # if query is None or new_values is None:
      if not query or not new_data:
          return 0
       
      try:
         result = self.collection.update_many(query, {"$set": new_data})
         return result.modified_count
      except PyMongoError:
          return 0
    
    # DELETE
  
    #def delete(self, query: Dict[str, Any]) -> int:
    def delete(self, query):
                               
        # Delete documents matching query. Returns number of deleted docs.
        # if query is None:
        if not query:
            return 0
    
        try:
           result = self.collection.delete_many(query)
           return result.deleted_count
        except PyMongoError:
            return 0
 
         