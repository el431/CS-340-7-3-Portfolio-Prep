# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from pymongo.errors import PyMongoError
from ur11ib.parse import quote_plus

class AnimalShelterCRUD(object): 
    
   # CRUD operations for Animal collection in MongoDB  
    def __init__(self, username, password):
                 user = quote_plus(username)
                 pwd = quote_plus(password)
                 
        
      # Initialize MongoDB connection using provided credentials.
        
        
        uri = f"mongodb://{user}:{pwd}@localhost:27017/?authSource=admin"
        
        try:
            
             self.client = MongoClient(uri) 
             self.database = self.client["aac"]
             self.collection = self.database["animals"] 
        
              # Force an auth/connection check
        
             self.client.admin.command("ping")
        
        except PyMongoError as e:
               raise ConnectionError(f"MongoDB connection failed: {e}")
                
                def create(self, data):
                    """ InsertFind documents. Returns list of results, else empty list. """
                    if data is None:
                        return False
                    
                try:
                    self.collection.insert_one(data)
                    return True
                except PyMongoError:
                    return False
                
                def read(self, query):
                    """"Find documents. Returns list of results, else empty list. """
                    if Query is None:
                        query = {}
                        try:
                            return list(self.collection.find(query))
                        except PyMongoError:
                            return []
                    
                

        